void init_ping(void);
void do_ping(void);
bool getInternetConnected(void);